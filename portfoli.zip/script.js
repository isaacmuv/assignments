footer{
  height: 50px; 
  background-color: brown; 
}
main{
height: 585px;
background-color: bisque;

}
#lean{
    background-color: aqua;
    border-radius: 5px;
    height: 30px;
    width: 200px;
    align-self: flex-start;
}